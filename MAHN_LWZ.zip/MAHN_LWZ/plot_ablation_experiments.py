import matplotlib.pyplot as plt
import numpy as np

# 创建示例数据
x = np.arange(6)  # 五个坐标点
bar_width = 0.15  # 柱子宽度

# 每个坐标点上的四个柱子的高度数据
data1 = [91.85, 90.48, 93.52, 91.94, 97.47, 97.39]
data2 = [89.20, 88.37, 90.36, 89.33, 96.49, 96.11]
data3 = [77.97, 82.90, 70.46, 76.07, 87.70, 86.27]
data4 = [91.05, 89.72, 92.90, 91.23, 96.93, 96.78]
data5 = [90.76, 91.18, 90.41, 90.73, 97.09, 96.70]

# 颜色设置
# colors = ['r', 'g', 'b', 'y', 'm']
# 使用 Set1 颜色循环，Matplotlib 将为每个柱子自动选择颜色
#colors = plt.cm.Set1(np.arange(6))  # 获取 Set1 颜色循环的颜色

# SCI配图颜色的RGB值
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']

# 绘制柱状图
plt.bar(x - 2*bar_width, data1, bar_width, color=colors[0], label='MAHN')
plt.bar(x - bar_width, data2, bar_width, color=colors[1], label='MAHN-no3')
plt.bar(x, data3, bar_width, color=colors[2], label='MAHN-no2')
plt.bar(x + bar_width, data4, bar_width, color=colors[3], label='MAHN-nosample')
plt.bar(x + 2*bar_width, data5, bar_width, color=colors[4], label='MAHN-noweight')

# 设置横坐标标签
plt.xticks(x, ['Acc', 'Pre', 'Recll', 'F1', 'AUPR', 'AUC'])
# plt.xlim([0.85, 5.15])
plt.ylim([70, 103.5])
# 添加图例
# plt.legend(loc='lower center')
# 添加图例，将图例放在坐标轴的外面  # bbox_to_anchor=(0.5, -0.07)调整图例的横纵位置
legend = plt.legend(loc='upper center', bbox_to_anchor=(0.5, 0.97), ncol=5)

# 添加标题和标签
# plt.title('柱状图示例')
# plt.xlabel('横坐标')
# plt.ylabel('%')

# 调整图的尺寸
plt.gcf().set_size_inches(10, 6)

# 显示柱状图
plt.savefig('result/ablation_experiments.pdf', format='pdf', dpi=300, bbox_inches='tight', bbox_extra_artists=(legend,))
plt.show()
plt.close()

