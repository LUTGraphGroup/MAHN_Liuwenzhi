import numpy as np
import pandas as pd

print('读取数据')

association_matrix_DMI = pd.read_excel('data/association_matrix_DMI.xlsx', sheet_name='Sheet1', header=0)
print('association_matrix_DMI', association_matrix_DMI)
association_matrix_DME = pd.read_excel('data/association_matrix_DME.xlsx', sheet_name='Sheet1', header=0)
print('association_matrix_DME', association_matrix_DME)
association_matrix_MIME = pd.read_excel('data/association_matrix_MIME.xlsx', sheet_name='Sheet1', header=0)
print('association_matrix_MIME', association_matrix_MIME)

def A_DMI_D(association_matrix_DMI):
    A_DMI = {}
    for column in association_matrix_DMI.columns:
        adjacent_diseases = association_matrix_DMI[association_matrix_DMI[column] == 1].index.tolist()
        A_DMI[column] = adjacent_diseases
    adjacent_nodes = [values for values in A_DMI.values()]
    A_DMI_D = np.zeros([association_matrix_DMI.shape[0], association_matrix_DMI.shape[0]])
    for i in range(len(adjacent_nodes)):
        for node in adjacent_nodes[i]:
            for node1 in adjacent_nodes[i]:
                if node != node1:
                    A_DMI_D[node, node1] = 1
                    A_DMI_D[node1, node] = 1
    print('A_DMI_D', A_DMI_D)
    result = pd.DataFrame(A_DMI_D)
    result.to_excel('data/A_DMID.xlsx', index=False)
    return A_DMI_D

def A_DME_D(association_matrix_DME):
    A_DME = {}
    for column in association_matrix_DME.columns:
        adjacent_diseases = association_matrix_DME[association_matrix_DME[column] == 1].index.tolist()
        A_DME[column] = adjacent_diseases
    adjacent_nodes = [values for values in A_DME.values()]
    A_DME_D = np.zeros([association_matrix_DME.shape[0], association_matrix_DME.shape[0]])
    for i in range(len(adjacent_nodes)):
        for node in adjacent_nodes[i]:
            for node1 in adjacent_nodes[i]:
                if node != node1:
                    A_DME_D[node, node1] = 1
                    A_DME_D[node1, node] = 1
    print('A_DME_D', A_DME_D)
    result = pd.DataFrame(A_DME_D)
    result.to_excel('data/A_DMED.xlsx', index=False)
    return A_DME_D

def A_DME_ME(association_matrix_DME):
    A_DME = {}
    for index, row in association_matrix_DME.iterrows():
        adjacent_diseases = row[row == 1].index.tolist()
        A_DME[index] = adjacent_diseases
    adjacent_nodes = [values for values in A_DME.values()]
    A_DME_ME = np.zeros([association_matrix_DME.shape[1], association_matrix_DME.shape[1]])
    for i in range(len(adjacent_nodes)):
        for node in adjacent_nodes[i]:
            for node1 in adjacent_nodes[i]:
                if node != node1:
                    A_DME_ME[node, node1] = 1
                    A_DME_ME[node1, node] = 1
    print('A_DME_ME', A_DME_ME)
    result = pd.DataFrame(A_DME_ME)
    result.to_excel('data/A_MEDME.xlsx', index=False)
    return A_DME_ME

def A_MIME_ME(association_matrix_MIME):
    A_MIME = {}
    for index, row in association_matrix_MIME.iterrows():
        adjacent_diseases = row[row == 1].index.tolist()
        A_MIME[index] = adjacent_diseases
    adjacent_nodes = [values for values in A_MIME.values()]
    A_MIME_ME = np.zeros([association_matrix_DME.shape[1], association_matrix_DME.shape[1]])
    for i in range(len(adjacent_nodes)):
        for node in adjacent_nodes[i]:
            for node1 in adjacent_nodes[i]:
                if node != node1:
                    A_MIME_ME[node, node1] = 1
                    A_MIME_ME[node1, node] = 1
    print('A_MIME_ME', A_MIME_ME)
    result = pd.DataFrame(A_MIME_ME)
    result.to_excel('data/A_MEMIME.xlsx', index=False)
    return A_MIME_ME

def main():
    A_DME_ME(association_matrix_DME)
main()


