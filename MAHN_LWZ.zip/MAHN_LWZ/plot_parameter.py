import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, FormatStrFormatter

def plot_dropout():
    X = [1, 2, 3, 4, 5]
    Y = [97.23, 97.39, 97.12, 96.67, 96.31]
    # plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    # plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax = plt.subplots()
    plt.plot(X, Y, color="darkorange", linewidth=2, linestyle="-",
             marker='o', markersize=7, markerfacecolor='darkorange')
    plt.xlim([0.85, 5.15])
    plt.ylim([96, 97.5])
    ax.set_xticks(X)  # 设置横坐标间距
    # 设置横坐标标签
    ax.set_xticklabels(['0.1', '0.2', '0.3', '0.4', '0.5'])  # 在这里可以设置自定义的标签

    x_major_locator = MultipleLocator(1)  # 以每0.05显示
    y_major_locator = MultipleLocator(0.25)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    ax.yaxis.set_major_locator(y_major_locator)

    plt.xlabel('dropout')
    plt.ylabel('Average AUC(%)')
    # plt.title('ROC curve')
    # plt.legend(loc='lower right')
    plt.savefig('result\dropout.pdf', format='pdf', dpi=300, bbox_inches='tight')
    plt.show()
    plt.close()
plot_dropout()


def plot_k_sample():
    X = [1, 2, 3, 4, 5]
    Y = [97.22, 97.00, 97.39, 96.80, 96.78]
    fig, ax = plt.subplots()
    # plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    # plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.plot(X, Y, color="g", linewidth=2, linestyle="-",
             marker='s', markersize=7, markerfacecolor='g')
    plt.xlim([0.8, 5.2])
    plt.ylim([96.50, 97.50])
    ax.set_xticks(X)  # 设置横坐标间距
    # 设置横坐标标签
    ax.set_xticklabels(['10', '30', '50', '70', '90'])  # 在这里可以设置自定义的标签

    x_major_locator = MultipleLocator(1)  # 以每0.05显示
    y_major_locator = MultipleLocator(0.25)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    ax.yaxis.set_major_locator(y_major_locator)

    plt.xlabel('Enhanced GraphSAGE sampling number K')
    plt.ylabel('Average AUC(%)')
    # plt.title('ROC curve')
    # plt.legend(loc='lower right')
    plt.savefig('result\k_sample.pdf', format='pdf', dpi=300, bbox_inches='tight')
    plt.show()
    plt.close()
plot_k_sample()


