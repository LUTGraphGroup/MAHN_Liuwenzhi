import torch
import torch.nn as nn
import torch.nn.functional as F

# GATLayer为了方便求解只含miRNA-疾病的聚合特征
# layers用于对比实验，判断节点层主义力相同时的情况
class GATLayer(nn.Module):
    def __init__(self, G, feature_attn_size, dropout, slope, device):
        super(GATLayer, self).__init__()
        self.device = device

        self.disease_nodes = G.filter_nodes(lambda nodes: nodes.data['type'] == 1)
        self.metabolite_nodes = G.filter_nodes(lambda nodes: nodes.data['type'] == 0)

        self.G = G
        self.slope = slope
        # G.ndata['m_sim'].shape[1]=383表示输入维数,feature_attn_size=64表示输出维数
        # nn.Linear(in_features, out_features, bias=True)用于进行特征映射、维度变换或特征转换等操作。线性层在深度学习中非常常见，可以用于构建全连接层、输出层、特征提取层等。
        # 线性变换的计算公式为：output = input @ weight^T + bias，其中 @ 表示矩阵乘法操作。在示例中，线性层会自动初始化权重和偏置项，并在计算过程中应用这些参数。
        self.me_fc = nn.Linear(G.ndata['me_sim'].shape[1], feature_attn_size, bias=False)  # 将输入特征进行线性变换，即对输入进行矩阵乘法和偏置相加的操作。
        self.d_fc = nn.Linear(G.ndata['d_sim'].shape[1], feature_attn_size, bias=False)
        self.dropout = nn.Dropout(dropout)
        # self.attn_fc = nn.Linear(feature_attn_size * 2, 1, bias=False)
        self.reset_parameters()

    def reset_parameters(self):
        gain = nn.init.calculate_gain('relu')
        nn.init.xavier_normal_(self.me_fc.weight, gain=gain)  # 多头每次生成的权重矩阵不一样，可以学到网络不同的信息
        nn.init.xavier_normal_(self.d_fc.weight, gain=gain)
        # nn.init.xavier_normal_(self.attn_fc.weight, gain=gain)

# 边的注意力系数
    def edge_attention(self, edges):
        """通过拼接的方式计算边注意力系数"""
        # print('SRC size:', edges.src['z'].size())
        # print('DST size: ', edges.dst['z'].size())
        # z2 = torch.cat([edges.src['z'], edges.dst['z']], dim=1)
        # a = self.attn_fc(z2)
        # return {'e': a}

        '''通过逐元素相乘的方式计算边注意力系数，a是每条边的注意力系数'''
        # edges.src['z'].mul(edges.dst['z']): 这段代码计算源节点 'z' 特征和目标节点 'z' 特征的逐元素乘积。
        # torch.sum(edges.src['z'].mul(edges.dst['z']), dim=1): 这段代码对逐元素乘积的结果进行按行求和，得到一个行向量。
        # .unsqueeze(1): 这个方法用于在求和结果上添加一个额外的维度，将其转换为列向量。
        a = torch.sum(edges.src['z'].mul(edges.dst['z']), dim=1).unsqueeze(1)
        return {'e': F.leaky_relu(a, negative_slope=self.slope)}  # 将所有边注意力系数[17376, 1]储存到键为‘e’的字典中

    # 消息函数:接受一个参数edges，该方法定义了边在消息传递过程中如何发送消息
    # 该方法从边的源节点中获取特征 z 和边的注意力系数 e，
    # 然后将它们作为字典键值对 'z' 和 'e' 返回，表示将这些信息作为消息发送给目标节点。
    def message_func(self, edges):
        return {'z': edges.src['z'], 'e': edges.data['e']}
    # 聚合函数接受一个nodes参数, 该方法定义了节点在消息传递过程中如何聚合接收到的消息。
    # nodes的成员属性mailbox可以用来访问节点收到的消息
    def reduce_func(self, nodes):
        # alpha注意力系数
        # 在消息传递过程中，每个节点会接收来自邻居节点的消息，并将这些消息存储在 nodes.mailbox 中。
        # nodes.mailbox 是一个字典结构，键是消息的字段名称，值是一个张量或数据结构，用于存储相应的消息内容。
        # 在上述代码中，'e' 和 'z' 分别是消息的字段名称，用于存储注意力系数和节点表示的消息。
        alpha = F.softmax(nodes.mailbox['e'], dim=1)  # 通过softmax对注意力系数进行归一化
        h = torch.sum(alpha * nodes.mailbox['z'], dim=1)

        return {'h': F.elu(h)}

    def forward(self, G):
        # self.d_fc(nodes.data['d_sim']) 表示对节点的 'd_sim' 特征应用线性变换层 self.d_fc，生成新的特征表示。
        # self.dropout(self.d_fc(nodes.data['d_sim'])) 表示对线性变换层的输出应用丢弃层 self.dropout，用于随机丢弃一部分特征，以增强模型的鲁棒性和泛化能力。
        # 通过调用 self.G.apply_nodes() 方法，将 lambda 函数应用于指定的节点列表 self.disease_nodes，并将更新后的节点特征保存在 'z' 这个键下。
        # 将疾病和miRNA节点的特征维数统一为64维
        self.G.apply_nodes(lambda nodes: {'z': self.dropout(self.d_fc(nodes.data['d_sim']))}, self.disease_nodes)
        self.G.apply_nodes(lambda nodes: {'z': self.dropout(self.me_fc(nodes.data['me_sim']))}, self.metabolite_nodes)
        # 该方法会遍历图中的每条边，调用edge_attention方法来计算边的注意力系数e。然后，将计算得到的注意力系数e更新到边的数据中
        self.G.apply_edges(self.edge_attention)
        # 对图中的所有节点进行消息传递和聚合操作
        # 对于每个节点，首先根据定义的 message_func 方法从节点的邻居边中获取消息，并将消息发送给目标节点。
        # 然后，根据定义的 reduce_func 方法，对目标节点接收到的消息进行聚合操作，得到更新后的节点表示。
        self.G.update_all(self.message_func, self.reduce_func)

        return self.G.ndata.pop('h')

# 多头注意力
class MultiHeadGATLayer(nn.Module):
    def __init__(self, G, feature_attn_size, num_heads, dropout, slope,device, merge='cat'):
        super(MultiHeadGATLayer, self).__init__()

        self.device = device
        self.G = G
        self.dropout = dropout
        self.slope = slope
        self.merge = merge

        self.heads = nn.ModuleList()  # nn.ModuleList()是PyTorch中的一个容器类，用于存储和管理神经网络模块的列表。
        # 可以通过迭代self.heads列表来访问和使用其中的模块，例如 for attn_head in self.heads
        for i in range(num_heads):
            self.heads.append(GATLayer(G, feature_attn_size, dropout, slope, device))  # self.heads 是一个包含多个注意力头部的列表

    def forward(self, G):
        head_outs = [attn_head(G) for attn_head in self.heads]  # 使用列表推导式将每个注意力头部应用于图 G 并获得输出
        if self.merge == 'cat':
            return torch.cat(head_outs, dim=1).to(self.device)
        else:
            return torch.mean(torch.stack(head_outs), dim=0).to(self.device)

# HAN_metapath_specific用于获得元路径为ml、dl时，miRNA和疾病的特征
class HAN_metapath_specific(nn.Module):
    def __init__(self, G, feature_attn_size, out_dim, dropout, slope, device):
        super(HAN_metapath_specific, self).__init__()
        self.device = device
        self.metabolite_nodes = G.filter_nodes(lambda nodes: nodes.data['type'] == 0)
        self.microbe_nodes = G.filter_nodes(lambda nodes: nodes.data['type'] == 2)
        self.disease_nodes = G.filter_nodes(lambda nodes: nodes.data['type'] == 1)

        self.G = G
        self.slope = slope

        self.me_fc = nn.Linear(G.ndata['me_sim'].shape[1], feature_attn_size, bias=False)  # 统一节点特征维数
        self.mi_fc = nn.Linear(G.ndata['mi_sim'].shape[1], feature_attn_size, bias=False)
        self.d_fc = nn.Linear(G.ndata['d_sim'].shape[1], feature_attn_size, bias=False)
        self.me_fc1 = nn.Linear(feature_attn_size + 495, out_dim)   # 设置全连接层
        self.d_fc1 = nn.Linear(feature_attn_size + 383, out_dim)
        self.attn_fc = nn.Linear(feature_attn_size * 2, 1, bias=False)
        self.dropout = nn.Dropout(dropout)
        self.reset_parameters()

    def reset_parameters(self):
        gain = nn.init.calculate_gain('relu')
        nn.init.xavier_normal_(self.me_fc.weight, gain=gain)
        nn.init.xavier_normal_(self.mi_fc.weight, gain=gain)
        nn.init.xavier_normal_(self.d_fc.weight, gain=gain)

    def edge_attention(self, edges):
        a = torch.sum(edges.src['z'].mul(edges.dst['z']), dim=1).unsqueeze(1)
        '''z2 = torch.cat([edges.src['z'], edges.dst['z']], dim=1)
        a = self.attn_fc(z2)'''
        return {'e': F.leaky_relu(a, negative_slope=self.slope)}

    def message_func(self, edges):
        return {'z': edges.src['z'], 'e': edges.data['e']}

    def reduce_func(self, nodes):
        alpha = F.softmax(nodes.mailbox['e'], dim=1)
        h = torch.sum(alpha * nodes.mailbox['z'], dim=1)

        return {'h': F.elu(h)}

    def forward(self, new_g, meta_path):
# 这里的图为传过来的新构建的子图
        if meta_path == 'dmi':
            new_g.apply_nodes(lambda nodes: {'z': self.dropout(self.d_fc(nodes.data['d_sim']))}, self.disease_nodes)
            new_g.apply_nodes(lambda nodes: {'z': self.dropout(self.mi_fc(nodes.data['mi_sim']))}, self.microbe_nodes)
            new_g.apply_edges(self.edge_attention)
            new_g.update_all(self.message_func, self.reduce_func)

            h_dmi = new_g.ndata.pop('h').to(self.device)

            return h_dmi

        elif meta_path == 'mime':
            new_g.apply_nodes(lambda nodes: {'z': self.dropout(self.mi_fc(nodes.data['mi_sim']))}, self.microbe_nodes)
            new_g.apply_nodes(lambda nodes: {'z': self.dropout(self.me_fc(nodes.data['me_sim']))}, self.metabolite_nodes)
            new_g.apply_edges(self.edge_attention)
            new_g.update_all(self.message_func, self.reduce_func)

            h_mime = new_g.ndata.pop('h').to(self.device)

            return h_mime

