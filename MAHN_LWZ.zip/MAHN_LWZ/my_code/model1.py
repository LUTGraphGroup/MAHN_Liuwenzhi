import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import dgl.nn as dglnn
from dgl.nn.pytorch import SAGEConv
from dgl.nn.pytorch import GraphConv
import numpy as np
# from mxnet import ndarray as nd
# from mxnet.gluon import nn as ng
from layers import MultiHeadGATLayer, HAN_metapath_specific

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


# 语义层注意力
# 主要用于修改数据，作比较模型，这里主要有两个地方：1.hidden_size; 2.beta
# 1是语义层向量q的维度变化对参数的影响；2是beta用于语义层贡献相同时的结果

class GraphSAGENeighborSampler(nn.Module):
    def __init__(self, graph, num_neighbors, out_feats=64):
        super(GraphSAGENeighborSampler, self).__init__()
        self.graph = graph
        self.features = self.graph.ndata['me_sim']
        self.num_neighbors = num_neighbors
        self.out_feats = out_feats
        # 计算边权重和边索引
        self.calculate_edge_weights()
        # 创建SAGEConv层
        self.sage_conv = SAGEConv(self.features.shape[1], out_feats=self.out_feats, aggregator_type='mean')

    def calculate_edge_weights(self):
        edges = self.graph.edges()
        # 初始化一个与边数相同的空张量，用于存储边权重
        self.edge_weights = torch.zeros(edges[0].shape[0])
        # 初始化一个列表，用于存储边的源节点和目标节点索引
        self.edge_indices = []
        # 遍历图中的每条边并计算点积权重
        for edge_id in range(edges[0].shape[0]):
            src = edges[0][edge_id].item()  # 获取源节点的索引
            dst = edges[1][edge_id].item()  # 获取目标节点的索引
            src_feats = self.graph.nodes[src].data['me_sim'].flatten()
            dst_feats = self.graph.nodes[dst].data['me_sim'].flatten()
            weight = torch.dot(src_feats, dst_feats)
            # 存储边的权重
            self.edge_weights[edge_id] = weight
            # 存储边的源节点和目标节点索引
            self.edge_indices.append((src, dst))
        # 将边权重分配给图的 'edge_weight' 属性
        self.graph.edata['edge_weight'] = self.edge_weights
        # 将边的索引信息存储在图的 'edge_indices' 属性中
        self.graph.edata['edge_indices'] = torch.tensor(self.edge_indices)

    def sample_neighbors_and_aggregate(self, input_data):
        updated_feature_list = []
        # 对每个节点执行邻居采样和特征聚合
        for node_id in range(self.graph.number_of_nodes()):
            # 获取节点的邻居边和权重
            neighbor_edges = self.graph.in_edges(node_id)
            # 获取邻居节点的索引信息
            src_nodes = neighbor_edges[0].tolist()
            dst_nodes = neighbor_edges[1].tolist()

            # 获取邻居边的索引信息
            edge_indices = self.graph.edata['edge_indices']

            # 初始化一个列表，用于存储匹配的权重
            neighbor_weights = []
            # 遍历邻居边，根据edge_indices匹配权重信息
            for i in range(len(src_nodes)):
                src = src_nodes[i]
                dst = dst_nodes[i]
                mask = (edge_indices[:, 0] == dst) & (edge_indices[:, 1] == src)
                matched_weights = self.edge_weights[mask]
                if len(matched_weights) > 0:
                    neighbor_weights.append(matched_weights.item())  # 假设权重是标量
            # 将权重列表转换为张量
            neighbor_weights = torch.tensor(neighbor_weights)

            # 根据权重从大到小进行邻居采样
            sorted_indices = torch.argsort(neighbor_weights, descending=True)
            topk_indices = sorted_indices[:self.num_neighbors]
            # 确保 topk_indices 是整数张量
            topk_indices = topk_indices.to(torch.int64)

            # 获取采样的邻居节点
            sampled_neighbors = (neighbor_edges[0][topk_indices], neighbor_edges[1][topk_indices])
            sampled_neighbors1 = neighbor_edges[0][topk_indices]
            node_themselves = torch.tensor([node_id])
            # 使用 torch.cat 将 节点自身 添加到 邻居节点 的最前面
            sampled_neighbors2 = torch.cat((node_themselves, sampled_neighbors1), dim=0)
            subgraph = self.graph.subgraph(sampled_neighbors2)

            # # 获取子图的边
            # edges = subgraph.edges()
            # # 打印源节点和目标节点
            # for src, dst in zip(edges[0], edges[1]):
            #     print(f"Source Node: {src}, Target Node: {dst}")

            # 获取节点自身和邻居节点的特征
            sampled_neighbor_feats = self.graph.ndata['me_sim'][sampled_neighbors2]

            # 聚合邻居信息（这里使用GraphSAGE聚合）
            aggregated_feats = self.sage_conv(subgraph, sampled_neighbor_feats)
            # print('aggregated_feats', aggregated_feats)
            updated_feature_list.append(aggregated_feats[0])

        # print('updated_feature_list)', updated_feature_list)
        # 将列表转换为张量
        updated_feature = torch.stack(updated_feature_list)
        return updated_feature

    def forward(self, input_data):
        # 在 forward 函数中执行采样和特征聚合
        return self.sample_neighbors_and_aggregate(input_data)


class SemanticAttention(nn.Module):
    def __init__(self, in_size, hidden_size=128):
        super(SemanticAttention, self).__init__()

        self.project = nn.Sequential(
            nn.Linear(in_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, 1, bias=False)
        )   # 实现论文等式（27）

    def forward(self, z):                               # [x, 2, 512]
        w = self.project(z).mean(0)  # 权重矩阵，获得元路径的重要性 [2, 1] .mean(0):每个meta_path上的均值（/|V|）;
        # beta = torch.softmax(w, dim=0)   # 疑问，为啥使用sigmod,而不是softmax进行归一化？
        beta = torch.sigmoid(w)
        beta = beta.expand((z.shape[0],) + beta.shape)  # [x,2,1] 扩展到N个节点上的metapath的值
        # delta = beta * z
        return (beta * z).sum(1)                        # [x, 512]

class HGANMDA(nn.Module):
    def __init__(self, G_D0, G_D1, G_ME0, G_ME1, hidden_dim, G, meta_paths_list, feature_attn_size, num_heads, num_diseases, num_metabolite, num_microbe,
                 d_sim_dim, me_sim_dim, mi_sim_dim, out_dim, dropout, slope, device):
        super(HGANMDA, self).__init__()
        # 其他初始化代码...
        self.device = device

        # self.conv3 = GraphConv(me_sim_dim, hidden_dim)
        # self.conv4 = SAGEConv(me_sim_dim, hidden_dim)

        self.G_D0 = G_D0
        self.G_D1 = G_D1
        self.G_ME0 = G_ME0
        self.G_ME1 = G_ME1
        self.G = G

        self.meta_paths = meta_paths_list
        self.num_heads = num_heads
        self.num_diseases = num_diseases
        self.num_metabolite = num_metabolite
        self.num_microbe = num_microbe

        self.conv1 = GraphConv(d_sim_dim, hidden_dim)
        # self.graphSAGENeighbor_sampler1 = GraphSAGENeighborSampler(graph=self.G_ME0, num_neighbors=10, out_feats=64)
        # self.graphSAGENeighbor_sampler2 = GraphSAGENeighborSampler(graph=self.G_ME1, num_neighbors=10, out_feats=64)
        self.sageconv = SAGEConv(me_sim_dim, hidden_dim, 'mean')

        self.gat = MultiHeadGATLayer(G, feature_attn_size, num_heads, dropout, slope, device, merge='cat')
        self.heads = nn.ModuleList()

        self.metapath_layers = nn.ModuleList()

        for i in range(self.num_heads):
            self.metapath_layers.append(HAN_metapath_specific(G, feature_attn_size, out_dim, dropout, slope,device))

        self.dropout = nn.Dropout(dropout)
        self.me_fc = nn.Linear(feature_attn_size * num_heads + me_sim_dim, out_dim*2)
        self.d_fc = nn.Linear(feature_attn_size * num_heads + d_sim_dim, out_dim*2)
        self.semantic_attention = SemanticAttention(in_size=out_dim * num_heads)

        self.h_fc = nn.Linear(out_dim*4, out_dim)
        # self.dropout = nn.Dropout(dropout)
        # self.m_fc = nn.Linear(m_sim_dim, out_dim, bias=False)
        # self.d_fc = nn.Linear(d_sim_dim, out_dim, bias=False)
        # self.fusion = nn.Linear(out_dim + feature_attn_size * num_heads, out_dim)
        self.predict = nn.Linear(out_dim * 2, 1)
        self.BilinearDecoder = BilinearDecoder(feature_size=64)
        self.InnerProductDecoder = InnerProductDecoder()

    def forward(self, G_D0, G_D1, G_ME0, G_ME1, G, G0, diseases, metabolite):  # G:GO_train  G0:GO
        # 第一层图卷积

        G_D0 = G_D0.to(self.device)
        G_D0.ndata['d_sim'] = G_D0.ndata['d_sim'].to(self.device)
        h_D0 = self.conv1(G_D0, G_D0.ndata['d_sim']).to(self.device)
        h_D0 = self.dropout(F.elu(h_D0)).to(self.device)

        G_D1 = G_D1.to(self.device)
        G_D1.ndata['d_sim'] = G_D1.ndata['d_sim'].to(self.device)
        h_D1 = self.conv1(G_D1, G_D1.ndata['d_sim']).to(self.device)
        h_D1 = self.dropout(F.elu(h_D1)).to(self.device)

        G_ME0 = G_ME0.to(self.device)
        G_ME0.ndata['me_sim'] = G_ME0.ndata['me_sim'].to(self.device)
        h_ME0 = self.sageconv(G_ME0, G_ME0.ndata['me_sim']).to(self.device)

        h_ME0 = self.dropout(F.elu(h_ME0)).to(self.device)

        G_ME1 = G_ME1.to(self.device)
        G_ME1.ndata['me_sim'] = G_ME1.ndata['me_sim'].to(self.device)
        h_ME1 = self.sageconv(G_ME1, G_ME1.ndata['me_sim']).to(self.device)

        h_ME1 = self.dropout(F.elu(h_ME1)).to(self.device)

        h_D = torch.cat((h_D0, h_D1), dim=1).to(self.device)

        h_ME = torch.cat((h_ME0, h_ME1), dim=1).to(self.device)

        index1 = 0
        for meta_path in self.meta_paths:
            if meta_path == 'dme' or meta_path == 'med':
                # 元路径为md和dm时，获得的聚合特征0-382是疾病特征。383-877是miRNA特征
                if index1 == 0:
                    h_agg0 = self.gat(G).to(self.device)
                    index1 = 1
            elif meta_path == 'dmi':
                # 元路径为ml，过滤边，构建子图，利用HAN_metapath_specific获得注意力特征
                dmi_edges = G0.filter_edges(lambda edges: edges.data['dmi']).to(self.device)
                # g_dmi = G0.edge_subgraph(dmi_edges).to(self.device)
                g_dmi = G0.edge_subgraph(dmi_edges, preserve_nodes=True)
                g_dmi = g_dmi.to(device)
                head_outs0 = [attn_head(g_dmi, meta_path) for attn_head in self.metapath_layers]
                h_agg1 = torch.cat(head_outs0, dim=1).to(self.device)   # 64维*8头=512维
            elif meta_path == 'mime':
                # 同元路径为dl
                mime_edges = G0.filter_edges(lambda edges: edges.data['mime']).to(self.device)
                g_mime = G0.edge_subgraph(mime_edges, preserve_nodes=True)
                g_mime=g_mime.to(self.device)
                head_outs1 = [attn_head(g_mime, meta_path) for attn_head in self.metapath_layers]
                h_agg2 = torch.cat(head_outs1, dim=1).to(self.device)

# 不同元路径疾病特征和不同元路径节点特征   有问题
        disease0 = h_agg0[:self.num_diseases].to(self.device)
        metabolite0 = h_agg0[self.num_diseases:self.num_diseases + self.num_metabolite].to(self.device)
        disease1 = h_agg1[:self.num_diseases].to(self.device)
        metabolite1 = h_agg2[self.num_diseases:self.num_diseases + self.num_metabolite].to(self.device)
        # h_d:(383,895)  h_m:(495,1007)
        # semantic_embeddings1 = []
        # semantic_disease = torch.cat((disease, disease), dim=1)
# 特征在dim=1堆叠
        semantic_embeddings1 = torch.stack((disease0, disease1), dim=1).to(self.device)
        h1 = self.semantic_attention(semantic_embeddings1).to(self.device)
        semantic_embeddings2 = torch.stack((metabolite0, metabolite1), dim=1).to(self.device)
        h2 = self.semantic_attention(semantic_embeddings2).to(self.device)

# 将经过语义层注意力得到的疾病特征和miRNA特征，和原来的疾病特征和miRNA特征连接  为什么？
        h_d = torch.cat((h1, self.G.ndata['d_sim'][:self.num_diseases]), dim=1).to(self.device)
        h_me = torch.cat((h2, self.G.ndata['me_sim'][self.num_diseases: self.num_diseases+self.num_metabolite]), dim=1).to(self.device)

        h_me = self.dropout(F.elu(self.me_fc(h_me))).to(self.device)       # （383,64）
        h_d = self.dropout(F.elu(self.d_fc(h_d))).to(self.device)       # （495,64）

        h_me_final = torch.cat((h_ME, h_me), dim=1).to(self.device)
        h_d_final = torch.cat((h_D, h_d), dim=1).to(self.device)


        h = torch.cat((h_d_final, h_me_final), dim=0).to(self.device)    # （878,64）
        h = self.dropout(F.elu(self.h_fc(h))).to(self.device)



# 获取训练边或测试边的点的特征
        h_diseases = h[diseases].to(self.device)    # disease中有重复的疾病名称;(17376,64)
        h_metabolite = h[metabolite].to(self.device)       # (17376,64)
# 全连接层得到结果
#         h_concat = torch.cat((h_diseases, h_metabolite), 1)         # (17376,128)
#         predict_score = torch.sigmoid(self.predict(h_concat))   # (17376,128)->(17376,128*2)->(17376,1)
#         return predict_score
        predict_score = self.BilinearDecoder(h_diseases, h_metabolite).to(self.device)
        # predict_score = self.InnerProductDecoder(h_diseases, h_mirnas)
        return predict_score

# 双线性解码器
class BilinearDecoder(nn.Module):
    def __init__(self, feature_size):
        super(BilinearDecoder, self).__init__()

        # self.activation = ng.Activation('sigmoid')  # 定义sigmoid激活函数
        # 获取维度为(embedding_size, embedding_size)的参数矩阵，即论文中的Q参数矩阵
        # 权重矩阵
        self.W = Parameter(torch.randn(feature_size, feature_size))

    def forward(self, h_diseases, h_metabolite):
        h_diseases0 = torch.mm(h_diseases, self.W)  # torch.mm 矩阵乘法操作
        h_metabolite0 = torch.mul(h_diseases0, h_metabolite)  # torch.mul 逐元素相乘
        # h_mirnas0 = h_mirnas.tanspose(0,1)
        # h_mirnsa0 = torch.mm(h_diseases0, h_mirnas0)
        # 将dim=1的维度缩减为1
        h0 = h_metabolite0.sum(1)  # 按行求和
        h = torch.sigmoid(h0)
        return h.unsqueeze(1)

# 内积解码器
class InnerProductDecoder(nn.Module):
    """Decoder model layer for link prediction."""
    def __init__(self):
        super(InnerProductDecoder, self).__init__()

    def forward(self, h_diseases, h_metabolite):
        x = torch.mul(h_diseases, h_metabolite).sum(1)
        x = torch.reshape(x, [-1])
        outputs = F.sigmoid(x)
        return outputs



